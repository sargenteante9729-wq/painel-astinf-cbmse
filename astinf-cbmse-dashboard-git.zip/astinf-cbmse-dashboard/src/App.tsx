import { useCallback, useMemo, useState, type CSSProperties } from 'react';
import {
  ArrowRight, Building2, ChevronRight, GitFork, LayoutDashboard, List,
  Play, Search, ShieldCheck, Users, X, Network, Menu
} from 'lucide-react';
import IntroVideo from './components/IntroVideo';
import { astinfLogo, cbmseLogo } from './lib/media';
import { sectors, type Sector } from './lib/sectors';

type View = 'dashboard' | 'map' | 'list';

function App() {
  const [selectedId, setSelectedId] = useState<string | null>('adm');
  const [view, setView] = useState<View>('dashboard');
  const [query, setQuery] = useState('');
  const [introOpen, setIntroOpen] = useState(true);
  const [mobileMenu, setMobileMenu] = useState(false);

  const selected = sectors.find(sector => sector.id === selectedId) ?? null;
  const filtered = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase('pt-BR');
    if (!normalized) return sectors;
    return sectors.filter(sector =>
      [sector.name, sector.label, sector.description, ...sector.responsibilities, ...sector.team]
        .join(' ')
        .toLocaleLowerCase('pt-BR')
        .includes(normalized),
    );
  }, [query]);

  const selectSector = useCallback((sector: Sector) => {
    setSelectedId(sector.id);
    setMobileMenu(false);
  }, []);

  return (
    <div className="app-shell">
      {introOpen && <IntroVideo onClose={() => setIntroOpen(false)} />}

      <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
        <div className="sidebar-brand"><img src={astinfLogo} alt="ASTINF" /></div>
        <p className="nav-caption">VISÃO GERAL</p>
        <button className={`nav-item ${view === 'dashboard' ? 'active' : ''}`} onClick={() => { setView('dashboard'); setMobileMenu(false); }}>
          <LayoutDashboard size={18} /> Painel de setores <ChevronRight size={16} />
        </button>
        <p className="nav-caption">SETORES DA ASSESSORIA</p>
        <nav aria-label="Setores da ASTINF">
          {sectors.map(sector => (
            <button key={sector.id} className={`nav-item ${selectedId === sector.id ? 'active' : ''}`} onClick={() => selectSector(sector)}>
              <span className="nav-sector-dot" style={{ background: sector.color }} />
              {sector.name}<ChevronRight size={16} />
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom"><ShieldCheck size={17} /><span>Corpo de Bombeiros Militar de Sergipe</span></div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobile-menu button button-outline" onClick={() => setMobileMenu(v => !v)} aria-label="Abrir ou fechar menu"><Menu size={19} /></button>
          <div className="breadcrumb"><span>Assessoria de TI</span><ChevronRight size={14} /><strong>Painel de setores</strong></div>
          <div className="institution"><img src={cbmseLogo} alt="Brasão CBMSE" /><span>Corpo de Bombeiros Militar de Sergipe</span><b>CBMSE</b></div>
        </header>

        <div className="workspace">
          <section className="hero">
            <div>
              <div className="eyebrow">TECNOLOGIA A SERVIÇO DA MISSÃO</div>
              <h1>ASTINF<span>.</span></h1>
              <p>Assessoria de Tecnologia da Informação</p>
            </div>
            <button className="button button-outline" onClick={() => setIntroOpen(true)}><Play size={17} /> Rever abertura</button>
          </section>

          <section className="summary" aria-label="Resumo da estrutura">
            <article className="summary-card"><Network /><strong>{sectors.length.toString().padStart(2, '0')}</strong><span>Setores cadastrados</span></article>
            <article className="summary-card"><Users /><strong>{sectors.reduce((sum, item) => sum + item.team.length, 0).toString().padStart(2, '0')}</strong><span>Registros de equipe</span></article>
            <article className="summary-card"><List /><strong>{sectors.reduce((sum, item) => sum + item.responsibilities.length, 0).toString().padStart(2, '0')}</strong><span>Atribuições cadastradas</span></article>
            <article className="summary-brand"><img src={astinfLogo} alt="ASTINF CBMSE" /></article>
          </section>

          <div className="toolbar">
            <div className="view-tabs" aria-label="Modo de visualização">
              <button className={view === 'dashboard' ? 'selected' : ''} onClick={() => setView('dashboard')}><LayoutDashboard size={17} /> Painel</button>
              <button className={view === 'map' ? 'selected' : ''} onClick={() => setView('map')}><GitFork size={17} /> Organograma</button>
              <button className={view === 'list' ? 'selected' : ''} onClick={() => setView('list')}><List size={17} /> Lista</button>
            </div>
            <label className="search">
              <Search size={17} />
              <input value={query} onChange={event => setQuery(event.target.value)} placeholder="Buscar setor ou atribuição..." aria-label="Buscar setor ou atribuição" />
              {query && <button onClick={() => setQuery('')} aria-label="Limpar pesquisa"><X size={15} /></button>}
            </label>
          </div>

          {view === 'dashboard' && (
            <section className="sector-grid" aria-label="Setores">
              {filtered.map((sector, index) => (
                <button key={sector.id} className={`sector-card ${selectedId === sector.id ? 'chosen' : ''}`} onClick={() => selectSector(sector)} aria-pressed={selectedId === sector.id}>
                  <div className="sector-card-top" style={{ '--sector-color': sector.color } as CSSProperties}>
                    <Building2 size={24} />
                    <span>{String(index + 1).padStart(2, '0')} / ASTINF</span>
                  </div>
                  <div className="sector-card-body">
                    <h3>{sector.name}</h3><p>{sector.label}</p>
                    <div className="sector-card-bottom"><span>{sector.responsibilities.length} atribuições</span><ArrowRight size={17} /></div>
                  </div>
                </button>
              ))}
              {filtered.length === 0 && <p className="empty">Nenhum setor encontrado para “{query}”.</p>}
            </section>
          )}

          {view === 'list' && (
            <section className="list-panel" aria-label="Lista de setores">
              {filtered.map(sector => <button className="list-row" key={sector.id} onClick={() => selectSector(sector)}><span className="nav-sector-dot" style={{ background: sector.color }} /><span><strong>{sector.name}</strong><small>{sector.label}</small></span><ChevronRight size={18} /></button>)}
              {filtered.length === 0 && <p className="empty">Nenhum setor encontrado para “{query}”.</p>}
            </section>
          )}

          {view === 'map' && (
            <section className="org-panel" aria-label="Organograma da ASTINF">
              <button className="org-root" onClick={() => setSelectedId(null)}><Network size={22} /><strong>ASTINF</strong><small>Assessoria de Tecnologia da Informação</small></button>
              <div className="org-connector" />
              <div className="org-grid">
                {filtered.map((sector, index) => <button key={sector.id} className={`org-node ${selectedId === sector.id ? 'chosen' : ''}`} onClick={() => selectSector(sector)}><span className="org-index">0{index + 1}</span><strong>{sector.name}</strong><small>{sector.label}</small></button>)}
              </div>
            </section>
          )}

          <section className="detail-panel" aria-live="polite">
            {selected ? <>
              <div className="detail-heading"><span className="detail-icon" style={{ background: selected.color }}><Building2 size={22} /></span><div><div className="eyebrow">DETALHAMENTO DO SETOR</div><h2>{selected.name}</h2><p>{selected.description}</p></div></div>
              <div className="detail-columns">
                <article><h3>Atribuições</h3><ul>{selected.responsibilities.map((item, index) => <li key={`${selected.id}-${index}`}>{item}</li>)}</ul></article>
                <article><h3>Equipe</h3>{selected.team.length ? <ul>{selected.team.map(person => <li key={person}>{person}</li>)}</ul> : <p className="muted">Os nomes e funções da equipe devem ser inseridos após validação dos dados oficiais.</p>}</article>
              </div>
            </> : <div className="root-detail"><Network size={28} /><div><h2>ASTINF — Visão geral</h2><p>Selecione um setor para consultar suas atribuições e informações.</p></div></div>}
          </section>

          <footer className="footer"><span>ASTINF · CBMSE</span><span>Painel organizacional · versão inicial</span></footer>
        </div>
      </main>
    </div>
  );
}

export default App;